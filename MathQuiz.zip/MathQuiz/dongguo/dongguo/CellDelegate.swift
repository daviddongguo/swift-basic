//
//  CellDelegate.swift
//  dongguo
//
//  Created by david on 2023-03-22.
//

protocol CellDelegate: ResultPageViewController  {
    func didRedoButtonPressedInCell(_ quiz: MathQuiz?)
}
