//
//  ListOfUsersViewController.swift
//  dongguo
//
//  Created by map07 on 2023-03-15.
//

import UIKit

class ListOfUsersViewController: UIViewController {
    
    var server: UserCollection?
    var currentUser: User?
    var string: String?

    @IBOutlet weak var listOfUsersLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let text = string {
            listOfUsersLabel.text = text
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String,
                                     sender: Any?) -> Bool {
        if server == nil || currentUser == nil {
            return false
        }
        return true

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? UpdatePasswordViewController {
            destination.currentUser = currentUser
            destination.server = server
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
